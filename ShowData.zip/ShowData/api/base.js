import request from '@/utils/request'
export const baseURL = process.env.API_BASE

// ??????
export function lineZc (data) {
  return request({
    url: '/recruitStation/search',
    method: 'post',
    baseURL,
    data
  })
};
