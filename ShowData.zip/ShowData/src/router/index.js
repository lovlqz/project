import Vue from 'vue'
import Router from 'vue-router'
import Passengers from '@/pages/Passengers'
import Statistics from '@/pages/Statistics'

Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      name: 'Passengers',
      component: Passengers
    },
    {
      path: '/Statistics',
      name: 'Statistics',
      component: Statistics
    }
  ]
})
