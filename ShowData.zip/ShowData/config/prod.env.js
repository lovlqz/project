'use strict'
module.exports = {
  NODE_ENV: '"production"',
  // 测试环境
  API_BASE: '"http://10.1.254.173:19080"'
}
